src/engine/ComputeEngine.java -> servidor implementado
src/client/Client.java -> cliente implementado
src/client/Command*.java -> implementação dos comandos de que são executados pelo servidor
src/database.txt -> o banco de dados

-------------------------------------------------------------------------------
Uso:

1- Executar src/engine/ComputeEngine.java e seguir o que for pedido pelos prints
2- Executar src/client/Client.java e seguir o que for pedido pelos prints
