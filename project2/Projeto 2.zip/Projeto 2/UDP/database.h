#include<json-c/json.h>

int test_database();

// Dado o email do perfil,retornar sua nome, sobrenome e foto
int list_person_info_by_email(char* email, char* res);
