Tanto na pasta TCP quanto UDP:
server.c -> servidor implementado
client.c -> cliente implementado
database.h -> header com as funções implementadas para o banco de dados
databse.c -> arquivo com as funções que executam os comandos desejados
database.json -> o banco de dados em si, onde os dados estão guardados
install.sh -> script para instalar as dependências do projeto
Makefile -> comandos para compilar o servidor e o cliente

-------------------------------------------------------------------------------
Uso:

sudo apt-get install git
sudo apt-get install cmake
sudo apt-get install autoconf automake libtool

chmod +x install.sh
./install.sh

make server
make client

./client HOSTNAME PORTA COMANDO "PARAMETROS"
./server PORTA
